package main

import (
	"fmt"
	"5th_module/maths"
)

func main() {
	fmt.Println(maths.Sum)
	fmt.Println(maths.Defference)
}
