package maths

var Number4 uint = 7                 // Присваиваем переменную 4 в формате uint
var Defference = Sum - int(Number4) // Присваиваем переменную 5 равную разнице переменных 3 и 4
