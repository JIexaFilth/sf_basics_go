package maths

var Number1 int = 11            //Назначаем целочисленную переменную 1
var Number2 int = 13            //Назначаем целочисленную переменную 2
var Sum int = Number1 + Number2 // Назначаем переменную 3 равную сумме переменных 1 и 2
